import OAI.NumberTheory.PiExponent.Ampleness.BlowupProperIntegral
import OAI.NumberTheory.PiExponent.Ampleness.WeightedProjectiveAmple
import OAI.NumberTheory.PiExponent.Approximation.WeightedGeometryScale
import LogarithmExtension.LogRatioGeometryData
import OAI.NumberTheory.PiExponent.Geometry.CurveMonomialMap
import LogarithmExtension.LogRatioJetIdeal

/-!
# Blow-up geometry of the two-base logarithmic jet ideal

Adapted from `OAI.BlowupGeometry` (Apache-2.0).
All data are independent of pi; the centre ideal is the two-base ideal
proved in `JetIdeal`.
-/

namespace LogarithmExtension.LogRatio
open OAI OAI.PiExponent OAI.PiExponentApprox

noncomputable section
namespace BlowupGeometry
open AlgebraicGeometry CategoryTheory TopologicalSpace
open PiExponentSeshadri.Geometry
open WeightedGeometryScale
variable (d : GeometryData)

def scale : Scale d.curveDegreeWeights d.curveJetWeights :=
  chooseScale d.curveDegreeWeights d.curveJetWeights
    d.curveDegreeWeights_pos d.curveJetWeights_pos

abbrev Index := (scale d).Index
abbrev exponents : Index d → Fin (d.m+2) →₀ ℕ := (scale d).exponents
abbrev constantIndex : Index d := (scale d).constantIndex d.curveDegreeWeights_pos
abbrev coordinateIndex : Fin (d.m+2) → Index d :=
  (scale d).coordinateIndex d.curveDegreeWeights_pos
abbrev pureIndex : Fin (d.m+2) → Index d :=
  (scale d).pureIndex d.curveDegreeWeights_pos

instance index_nonempty : Nonempty (Index d) := ⟨constantIndex d⟩

abbrev compactification : Scheme := Proj (WeightedCompactification.imageGrade (R := ℂ) (exponents d))

def compactificationStructureMap : compactification d ⟶ Spec (.of ℂ) :=
  WeightedCompactification.projection (exponents d)

instance compactificationStructureMap_proper : IsProper (compactificationStructureMap d) := by
  dsimp [compactificationStructureMap]
  infer_instance

def affineChart : JetIdeal.affineSpace d.m ⟶ compactification d :=
  WeightedCompactification.affineChartMap (exponents d) (constantIndex d)
    ((scale d).exponents_constant d.curveDegreeWeights_pos)
    (coordinateIndex d) ((scale d).exponents_coordinate d.curveDegreeWeights_pos)

instance affineChart_isOpenImmersion : IsOpenImmersion (affineChart d) := by
  dsimp [affineChart]
  infer_instance

def origin : JetIdeal.affineSpace d.m :=
  ⟨WeightedBezout.pointIdeal (0 : Fin (d.m+2) → ℂ),inferInstance⟩

instance compactification_nonempty : Nonempty (compactification d) := ⟨affineChart d (origin d)⟩
instance compactification_isIntegral : IsIntegral (compactification d) := by infer_instance
instance compactification_isLocallyNoetherian : IsLocallyNoetherian (compactification d) :=
  LocallyOfFiniteType.isLocallyNoetherian (compactificationStructureMap d)
instance compactification_compact : CompactSpace (compactification d) :=
  QuasiCompact.compactSpace_of_compactSpace (compactificationStructureMap d)
instance compactification_isNoetherian : IsNoetherian (compactification d) := {}
instance affineChart_quasiCompact : QuasiCompact (affineChart d) := by infer_instance

theorem affineChart_over : affineChart d ≫ compactificationStructureMap d =
    JetIdeal.structureMap d.m :=
  CurveMonomialMap.affineChartMap_projection (exponents d) (constantIndex d)
    ((scale d).exponents_constant d.curveDegreeWeights_pos)
    (coordinateIndex d) ((scale d).exponents_coordinate d.curveDegreeWeights_pos)

def hyperplane : LineBundle (compactification d) := WeightedCompactification.lineBundle (exponents d)
theorem hyperplane_ample : (hyperplane d).IsAmple :=
  WeightedCompactification.lineBundle_ample (exponents d)

def logCutoff : Fin d.m → ℕ :=
  fun i => (exists_log_cutoff (m := d.m+1) d.curveJetWeights
    (d.curveJetWeights_pos 0)).choose i.succ

theorem logCutoff_strict (i : Fin d.m) :
    d.curveJetWeights i.succ.succ < (logCutoff d i : ℚ) * d.curveJetWeights 0 :=
  (exists_log_cutoff (m := d.m+1) d.curveJetWeights
    (d.curveJetWeights_pos 0)).choose_spec i.succ

theorem logCutoff_strict_second (i : Fin d.m) :
    d.curveJetWeights i.succ.succ < (logCutoff d i : ℚ) * d.curveJetWeights 1 := by
  rw [d.jet_base_eq]
  exact logCutoff_strict d i

def centerIdeal : (compactification d).IdealSheafData :=
  JetIdeal.compactIdeal d.centerY d.centerZ d.curveCenters d.slopes
    (logCutoff d) (scale d).jetPowers (affineChart d)

theorem centerIdeal_restrict : (centerIdeal d).comap (affineChart d) =
    JetIdeal.affineIdeal d.centerY d.centerZ d.curveCenters d.slopes
      (logCutoff d) (scale d).jetPowers :=
  JetIdeal.restrict_compactIdeal _ _ _ _ _ _ _

theorem centerIdeal_support : ((centerIdeal d).support : Set (compactification d)) =
    ⋃ j : Fin d.K, Set.range
      (JetIdeal.point (d.centerY j) (d.centerZ j) (d.curveCenters j) ≫ affineChart d) :=
  JetIdeal.support_compactIdeal d.centerY d.centerZ d.centerY_ne_zero d.centerZ_ne_zero
    d.curveCenters d.slopes (logCutoff d) (scale d).jetPowers (scale d).jetPowers_pos
    (affineChart d) (compactificationStructureMap d) (affineChart_over d)

theorem centerIdeal_support_finite :
    ((centerIdeal d).support : Set (compactification d)).Finite := by
  rw [centerIdeal_support]
  exact Set.finite_iUnion (fun _ => Set.finite_range _)

theorem centerIdeal_support_subset_chart :
    ((centerIdeal d).support : Set (compactification d)) ⊆ (affineChart d).opensRange := by
  rw [centerIdeal_support]
  intro x hx
  obtain ⟨j,z,rfl⟩ := Set.mem_iUnion.mp hx
  exact ⟨JetIdeal.point (d.centerY j) (d.centerZ j) (d.curveCenters j) z,rfl⟩

theorem centerIdeal_coherent :
    (PiExponentSeshadri.IdealModule.closedModule (centerIdeal d)).IsFinitePresentation :=
  JetIdeal.compactIdeal_isFinitePresentation _ _ _ _ _ _ _

theorem origin_ne_center (y z : ℂ) (hy : y ≠ 0) (c : Fin d.m → ℂ) :
    origin d ≠ JetIdeal.centerPoint y z c := by
  intro h
  have hx : MvPolynomial.X (0 : Fin (d.m+2)) ∈ (origin d).asIdeal := by
    change MvPolynomial.aeval (0 : Fin (d.m+2) → ℂ) (MvPolynomial.X 0) = 0
    simp
  rw [h] at hx
  change MvPolynomial.aeval (AlgebraicJet.center y z c) (MvPolynomial.X 0) = 0 at hx
  exact hy (by simpa [AlgebraicJet.center] using hx)

theorem origin_avoids_center : affineChart d (origin d) ∉ (centerIdeal d).support := by
  change affineChart d (origin d) ∉ ((centerIdeal d).support : Set (compactification d))
  rw [centerIdeal_support]
  intro h
  obtain ⟨j,hj⟩ := Set.mem_iUnion.mp h
  obtain ⟨z,hz⟩ := hj
  have he : JetIdeal.point (d.centerY j) (d.centerZ j) (d.curveCenters j) z = origin d :=
    (affineChart d).isOpenEmbedding.injective hz
  have hc : JetIdeal.point (d.centerY j) (d.centerZ j) (d.curveCenters j) z =
      JetIdeal.centerPoint (d.centerY j) (d.centerZ j) (d.curveCenters j) := by
    apply Set.mem_singleton_iff.mp
    erw [← JetIdeal.range_point]
    exact ⟨z,rfl⟩
  exact origin_ne_center d _ _ (d.centerY_ne_zero j) _ (he.symm.trans hc)

theorem centerIdeal_support_ne_top : (centerIdeal d).support ≠ ⊤ := by
  intro h
  exact origin_avoids_center d (by rw [h]; trivial)

abbrev blowup : Scheme := PiExponentSeshadri.BlowupGluing.scheme (centerIdeal d)
abbrev projection : blowup d ⟶ compactification d :=
  PiExponentSeshadri.BlowupGluing.projection (centerIdeal d)
def structureMap : blowup d ⟶ Spec (.of ℂ) := projection d ≫ compactificationStructureMap d

instance projection_proper : IsProper (projection d) := by infer_instance
instance structureMap_proper : IsProper (structureMap d) := by
  dsimp [structureMap]
  infer_instance
instance blowup_isIntegral : IsIntegral (blowup d) :=
  PiExponentSeshadri.BlowupGluing.scheme_isIntegral (centerIdeal d) (centerIdeal_support_ne_top d)
instance blowup_isLocallyNoetherian : IsLocallyNoetherian (blowup d) :=
  LocallyOfFiniteType.isLocallyNoetherian (structureMap d)
instance blowup_compact : CompactSpace (blowup d) :=
  QuasiCompact.compactSpace_of_compactSpace (structureMap d)
instance blowup_isNoetherian : IsNoetherian (blowup d) := {}

def A : LineBundle (blowup d) := (hyperplane d).pullback (projection d)
abbrev J : LineBundle (blowup d) :=
  PiExponentSeshadri.BlowupGluing.exceptionalLineBundle (centerIdeal d)
abbrev exceptionalInclusion : (J d).sheaf ⟶ structureSheaf (blowup d) :=
  PiExponentSeshadri.BlowupGluing.exceptionalInclusion (centerIdeal d)

theorem exceptional_presents :
    PresentsPullbackIdeal (centerIdeal d) (projection d) (J d) (exceptionalInclusion d) :=
  PiExponentSeshadri.BlowupGluing.exceptional_presents (centerIdeal d)

theorem isBlowup : IsBlowup (centerIdeal d) (projection d) :=
  PiExponentSeshadri.BlowupGluing.isBlowup (centerIdeal d)

abbrev affinePolynomialIdeal :=
  JetIdeal.polynomialIdeal d.centerY d.centerZ d.curveCenters d.slopes
    (logCutoff d) (scale d).jetPowers

theorem formalJet_packet_zero (n : ℕ) (P : PolynomialFrame.Poly d.m)
    (hP : P ∈ affinePolynomialIdeal d ^ n) (j : Fin d.K) :
    JetGeometry.rationalCoefficientPacket d.curveJetWeights (n * (scale d).radius)
      (FormalJet.formalJet (d.centerY j) (d.centerZ j) (d.curveCenters j) d.slopes P) =
        (fun _ => (0 : ℂ)) := by
  apply JetIdeal.formalJet_packet_zero_of_mem_pow
    d.centerY d.centerZ d.centerY_ne_zero d.centerZ_ne_zero d.curveCenters d.slopes
    (logCutoff d) (scale d).jetPowers d.curveJetWeights
    (fun i => (d.curveJetWeights_pos i).le) (fun i => (logCutoff_strict d i).le)
    (fun i => (logCutoff_strict_second d i).le)
    (scale d).radius (fun i => ?_) n P hP j
  rw [mul_comm, (scale d).jetPowers_eq]

#print axioms centerIdeal_support
#print axioms formalJet_packet_zero

end BlowupGeometry

end

end LogarithmExtension.LogRatio
